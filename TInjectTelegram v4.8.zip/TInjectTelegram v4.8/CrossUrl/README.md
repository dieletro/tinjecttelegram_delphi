# CrossUrl
Biblioteca para usar bibliotecas de rede do usuário final.

**Installing and other info: see [wiki-page](https://github.com/ms301/CrossUrl/wiki)**
