﻿# TInjectTelegram



Este Componente Foi desenvoilvido pela *ITDevCon*
em projeto **colaborativo** de código aberto e Adaptado por Ruan Diego Lacerda Menezes
para uso com ChatBots e Integração com os metodos do TInject(por Mike Lustosa) para WhatsApp


Para Obter as Ultimas Atualizações add por mim, acesse aqui
# TInjectTelegram para Delphi
[github] 
***https://github.com/dieletro/tinjecttelegram_2020_delphi



# LMCODE TInjectTelegram ATUALIZAÇÃO 2020 para Delphi e Telegram
Código Atualizado para a Ultima versão da API do Telegram, versão 4.8 de 24 de Abril de 2020.
Nome dos Objetos Modificados.
Criado Novos Metodos para poder converter tipos distintos de array of string para JSonString
Adicionado novos Objetos em conformidade com a API
Correção de Bugs 
Atualização de recursos desde a versão 3.5.5 até a 4.8

Adicionado a função SendPool (Envio de Enquetes e Quiz).
Adicionado a função SendDice (Envio de um Dado ou um Dardo animado).
Corrigida a função SendLocation (Envio de Localização).
Corrigida a função SendVenue (Envio de Localização com Texto).

As seguintes pessoas contribuíram para esta biblioteca:
#///////////////////////////////////////////////////////////////////////////////////
Ruan Diego Lacerda Menezes (dieletro). 03/03/2020 
	[whatsapp]: ***+5521997196000,  
	[telegram]: ***@diegoguitarra,  
	[email]: ***diegolacerdamenezes@gmail.com,
	[instagram]: ***lacerdamenezes.

#///////////////////////////////////////////////////////////////////////////////////
Renat Suleymanov (Al-muhandis);
#///////////////////////////////////////////////////////////////////////////////////
Bonmario;
#///////////////////////////////////////////////////////////////////////////////////
@ashumkin (Alexey Shumkin);
#///////////////////////////////////////////////////////////////////////////////////
Ilya Bukhonin (MstrVLT);
#///////////////////////////////////////////////////////////////////////////////////
Daniele Spinetti (spinettaro);

# CrossUrl
Biblioteca para usar bibliotecas de rede do usuário final.

***Instalação e outras informações consulte:*** 
[wiki-page] **https://github.com/ms301/CrossUrl/wiki
[github]    **https://github.com/ms301/CrossUrl

Para utilizar é necessário ter instalado o CrossURL, disponível no endereço:
[github]
***https://github.com/kitesoft/itdevcon_2018_delphi_telegram/tree/master/libs/CrossUrl
ou
[github]
***https://github.com/ms301/CrossUrl

Para obter o código original, acesse:
# Delphi Telegram
[github] 
***https://github.com/kitesoft/itdevcon_2018_delphi_telegram